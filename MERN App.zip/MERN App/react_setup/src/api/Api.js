import axios from "axios";
import { getToken, setToken, setuserDetail } from "../utils/Helper";

const baseUrl = "http://localhost:5001/api/test";

const header = {};

export const loginUser = async (body) => {
  try {
    const response = await axios.post(`${baseUrl}/login`, body);
    // console.log("gggggggr", response.data);
    setToken(response.data.jsontoken);
    setuserDetail(response.data.data);
    return response;
  } catch (error) {
    throw new Error("login error");
  }
};

export const getUsercreate = async (body) => {
  try {
    const response = await axios.post(
      `${baseUrl}/create`,
      {
        name: body.name,
        email: body.email,
        mobile: body.mobile,
        city: body.city,
        password: body.password,
      },
    );
    return response;
  } catch (error) {
    throw new Error("Create user Error");
  }
};

export const getPostcreate = async (body) => {
  header.authorization = `${getToken()}`;
  try {
    // console.log(body,"bodyyyyyy")
    const response = await axios.post(`${baseUrl}/createpost`, {
      userId: body.userId,
      title: body.title,
      content: body.content,
    },{ headers: header });
    return response;
  } catch (error) {
    throw new Error("Create Post Error");
  }
};

export const getUserPosts = async () => {
  header.authorization = `${getToken()}`;
  try {
    const response = await axios.post(`${baseUrl}/getallpost`, {
      userId: JSON.parse(localStorage.getItem("user"))._id,
    }, {headers: header});
    return response;
  } catch (error) {
    throw new Error("Get Posts Error");
  }
};

export const getDeletePosts = async (id) => {
  header.authorization = `${getToken()}`;
  try {
    const response = await axios.delete(`${baseUrl}/deletepost/${id}`,{headers:header});
    return response;
  } catch (error) {
    throw new Error("Delete posts Error");
  }
};

export const updatePosts = async (id) => {
  header.authorization = `${getToken()}`;
  try {
    const response = await axios.post(`${baseUrl}/updatepost/${id}`,{headers:header});
    return response;
  } catch (error) {
    throw new Error("Update posts Error");
  }
};
