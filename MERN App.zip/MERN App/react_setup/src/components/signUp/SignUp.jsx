import "./appR.css";
import React, { useEffect, useState } from "react";
import FormInput from "./FormInput"
import { NavLink, useNavigate } from "react-router-dom";
import {Button} from "react-bootstrap"
import { getUsercreate } from "../../api/Api";

const App = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    mobile: "",
    city: "",
    password:"",
    confirmPassword:"",
    isError: false,
  })

  const [error, setError] = useState({
    name: "",
    email: "",
    mobile: "",
    city: "",
    password:"",
    confirmPassword:"",
    isError: false,
  });

  
  const inputs = [
    {
      id: 1,
      name: "name",
      type: "text",
      placeholder: "Enter Name",
      errorMessage:
        "Please Enter Name",
      label: "Name*",
      required: true,
    },
    {
      id: 2,
      name: "email",
      type: "email",
      placeholder: "Email",
      errorMessage: "It should be a valid email address!",
      label: "Email*",
      pattern: "/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/",
      required: true,
    },
    {
      id: 3,
      name: "mobile",
      type: "number",
      placeholder: "Enter Number",
      errorMessage:
        "Please enter mobile number",
      label: "Mobile Number*",
      // pattern: "^[A-Za-z0-9]{3,16}$",
      pattern: "/^(\+\d{1,3}[- ]?)?\d{10}$/",
      min: 6000000000,
      max: 9999999999,
      required: true,
    },
    {
      id: 4,
      name: "city",
      type: "Name",
      placeholder: "City",
      errorMessage: "Please Enter City",
      label: "City",
      // pattern: `^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$`,
      // required: true,
    },
    {
      id: 5,
      name: "password",
      type: "password",
      placeholder: "Password",
      errorMessage:
        "Password should be 8-20 characters and include at least 1 letter, 1 number and 1 special character!",
      label: "Password*",
      pattern: `^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$`,
      required: true,
    },
    {
      id: 6,
      name: "confirmPassword",
      type: "password",
      placeholder: "Confirm Password",
      errorMessage:
        "Password should be 8-20 characters and include at least 1 letter, 1 number and 1 special character!",
      label: "Confirm Password*",
      pattern: `^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$`,
      required: true,
    },
  ];

  const handleSubmit = (e) => {
    console.log("sssssssssssssss", e)
    e.preventDefault();
    
    if (formData.confirmPassword != formData.password) {
      console.log("pasworddddddddddddddddd")
      console.log(formData.confirmPassword,"formData.confirmPassword");
      console.log(formData.password,"formData.password");

      return setError({
        isError: true,
        confirmPassword:"Password and Confirm Password does not match"
      });
  }
 
  else{
    setError({ isError: false });
    getUsercreate({
      name: formData.name,
      email: formData.email,
      mobile: formData.mobile,
      city: formData.city,
      password: formData.password,
    }).then((response) => {
      console.log(response)
      setFormData(response)
      navigate('/login')
    })
      .catch(() => {
        formData.serverError = "User already exists!";
        setError(formData);
      });
  }
  }
  console.log(formData,"formDataaaaaaaaaaaaaa");


  const onChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value.trim()});
  };
  // const onClickPicBtn = async () => {
  //   console.log("fileeeeeeeeeeeee")
  //   try {
  //     const imgData = await imgInputFilePicker();
  //     setFormData({
  //       ...formData,
  //       photo: imgData.base64,
  //       photoName: imgData.name,
  //     });
  //   } catch {
  //     console.log("error");
  //   }
  // };
  const onClickBack=() =>{
    navigate('/login')
  }
  
  return (
    <>
    <nav className="navbar navbar-expand-lg bg-light">
        <div className="container-fluid">
          <a className="navbar-brand" href="#">
            DotSquares
          </a>
        </div>
        <button type="button" className="btn btn-secondary" onClick={() =>{ navigate('/login')}}>Back</button>
      </nav>
      <div className="app">
        <form onSubmit={handleSubmit}>
          <h1>Registration</h1>
          {inputs.map((input) => (
            <FormInput
              key={input.id}
              {...input}
              value={formData[input.name]}
              onChange={onChange}
            />
          ))}
          <p style={{ color: "red" }}>{error.confirmPassword}</p>
          <button>Submit</button>
          </form>
            </div>
    </>
  );
};

export default App;