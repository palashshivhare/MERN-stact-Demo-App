import React, { useEffect, useState } from "react";
import Navigation from "../navigation/Navigation";
import { Modal, Button, Spinner } from "react-bootstrap";
import delete_icons from "../../assets/images/delete_icons.svg";
import noContactImage from "../../assets/images/no-contact1.svg";

import { useDispatch } from "react-redux";
import { edit } from "../../store/UpdateSlice";

import { getuserDetail } from "../../utils/Helper";

import {
  getPostcreate,
  getUserPosts,
  getDeletePosts,
} from "../../api/Api";
import { useNavigate } from "react-router-dom";

const Home = (props) => {
  const navigate = useNavigate();
  const [show, setShow] = useState(false);
  const [showD, setShowD] = useState(false);

  const [deleteId, setDeleteId] = useState("");
  const [isLoading, setLoading] = useState(false);

  const [postLists, setPostLists] = useState([]);
  const [postDetails, setPostDetails] = useState({
    id: "",
    title: "",
    content: "",
  });
  const [error, setError] = useState({
    isError: false,
    title: "",
    content: "",
  });

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleCloseD = () => setShowD(false);
  const handleShowD = () => setShowD(true);

  const deleteIdfn = (id) => {
    console.log(id, "iddddddddddddddddddd")
    setDeleteId(id);
  }

  useEffect(() => {
    let userdata = JSON.parse(localStorage.getItem("user"));
    // console.log("vvvvvvvvvvvvvvvvvvvvv",userdata)
    if (userdata && userdata?._id) {
      console.log("iffffffffffffffffffffffffff", userdata?._id);

      // navigate('./homepage')
    } else {
      console.log("elseeeeeeeeeeeeeeeeeeeeee", userdata?._id);
      navigate("/login");
    }
  }, []);

  //   ==================================Get Posts========================================

  useEffect(() => {
    setLoading(true);
    getData();
  }, []);
  //   console.log(postLists, "postlistttttttt");

  const getData = () => {
    getUserPosts()
      .then((response) => {
        console.log(response.data.data);
        setPostLists(response.data.data);
      })
      .catch(() => {
        console.log("catchhhhhh");
        setPostLists([]);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  //  ======================================Create Post========================================

  const onClickPost = () => {
    if (postDetails.title.length === 0) {
      return setError({
        isError: true,
        title: "Please Enter Title",
      });
    }
    if (postDetails.content.length === 0) {
      console.log("content errorrrrr");
      return setError({
        isError: true,
        content: "Please Enter Content",
      });
    } else {
      setError({ isError: false });
      getPostcreate({
        userId: getuserDetail()._id,
        title: postDetails.title,
        content: postDetails.content,
      }).then((response) => {
        console.log(response.data.data);
        setShow(false);
        setPostDetails({
          title: "",
          content: "",
        });
        getData();
      })
      .catch(() => {
        console.log("catchhhhhh");
        setError({isError:true, msg:"Create Post Error"});
      })
    }
  };

  //   ==================================Delete Posts========================================

  const onclickDeletePosts = (e) => (a) => {
    console.log("deleteeeeeeee", e);
    // console.log("ffffff",a);
    getDeletePosts(deleteId).then((result) => {
      console.log("deleted sucessfully", result);
      getData();
      setShowD(false);
    });
  };

  // const onClickEdit = () => {
  //   console.log("edittttt Posts");
  //   navigate('/updatePosts')
  // };
  const dispatch = useDispatch()
  
  let onClickEdit = (item) =>  {

    dispatch(edit(item))
    console.log("ttttttttttttttt",item)
    // const id = item._id;
    // props._id = item._id;
    // props.title = item.title;
    // props.content = item.content;
    // props={_id:item._id,title:item._id,content:item._id}
    // console.log("data:::", id);
    // localStorage.setItem("postSelectId", id);
    
    navigate('/updatePosts')
  };


  return (
    <>
      <Navigation />
      <div className="row">
        <div className="col-md-8"></div>
        <div className="col-md-4 mr-2" style={{ textAlign: "right" }}>
          <div>
            <div>
              <button className="btn btn-primary" onClick={handleShow}>
                Create Post
              </button>
            </div>
          </div>
        </div>
      </div>
      {isLoading === true ? (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            width: "100%",
          }}
        >
          <Spinner animation="border" variant="primary" />
        </div>
      ) : postLists.length ? (
        postLists.map((data, i) => (
          <div className="container" key={i}>
            <div className="card">
              <div className="card-body">
                <div
                  className="mediaarrow removebox"
                  style={{ textAlign: "right" }}
                >
                  <Button
                    variant="outline-dark"
                    onClick={()=>onClickEdit(data)}
                  >
                    Edit
                  </Button>
                  <button
                    className="mediaarrow removebox btn deleteCer"
                    // onClick={handleShowD}
                    onClick={() => {
                      deleteIdfn(data._id);
                      handleShowD();
                    }}
                    // onClick={onclickDeletePosts(data._id)}
                  >
                    <img src={delete_icons} className="" />
                  </button>
                </div>
                <h5 className="card-title">{data.title}</h5>
                <p className="card-text">{data.content}</p>
              </div>
            </div>
          </div>
        ))
      ) : (
        <div className=" text-center nocontact">
          <img src={noContactImage} style={{ width: "25%" }} alt="no contact" />
          <h3 className="pt-4">No posts found</h3>
        </div>
      )}
      {/* =====================================Create Modal============================================= */}
      <Modal centered show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Create Post</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <label htmlFor="exampleFormControlInput1">Title</label>
          <input
            className="form-control form-control-lg"
            type="text"
            placeholder="Enter Title"
            value={postDetails.title}
            onChange={(e) =>
              setPostDetails({ ...postDetails, title: e.target.value })
            }
          />
          <p style={{ color: "red" }}>{error.title}</p>

          <label htmlFor="exampleFormControlInput1">Content</label>
          <input
            className="form-control form-control-lg"
            type="text"
            placeholder="Enter Content"
            value={postDetails.content}
            onChange={(e) =>
              setPostDetails({
                ...postDetails,
                content: e.target.value,
              })
            }
          />
          <p style={{ color: "red" }}>{error.content}</p>
          <p style={{ color: "red" }}>{error.msg}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={onClickPost}>
            Submit
          </Button>
        </Modal.Footer>
      </Modal>
      {/* =====================================Delete Modal============================================= */}
      <Modal centered show={showD} onHide={handleCloseD}>
        <Modal.Header closeButton>
          <Modal.Title>Delete</Modal.Title>
        </Modal.Header>
        <Modal.Body>Are you sure you want to delete this contact ?</Modal.Body>
        <Modal.Footer>
          <button
            type="button"
            className="btn btn-primary btnwidoutbg btn1"
            onClick={handleCloseD}
          >
            Cancel
          </button>
          <Button variant="primary" onClick={onclickDeletePosts()}>
            Delete
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};
export default Home;
