import React, { useState, useEffect } from "react";
import Navigation from "../navigation/Navigation";
import { useSelector } from "react-redux";

import { Button } from "react-bootstrap";
import { NavLink, useNavigate } from "react-router-dom";

import { updatePosts, getUserPosts } from "../../api/Api";
import { nameRegex } from "../../utils/regex";

const UpdatePosts = (props) => {
  const items = useSelector((state) =>state.update[0]);
  console.log(items._id,"itemssssssssssssss")
    console.log("propsssssssssss",props)
  const navigate = useNavigate();
  const [updatePosts, setUpdatePosts] = useState({
    _Id: items?._id,
    title: items?.title,
    content: items?.content,
  });

  const [inputError, setInputError] = useState({
    title: "",
    content: "",
    isError: false,
  });

  useEffect(() => {
    let userId = localStorage.getItem("postSelectId");
    console.log(userId, "userIdddddddd");
    getUserPosts(userId).then((response) => {
      console.log(response.data.data);
      setUpdatePosts(response.data.data);
    });
  }, []);

  const changeInput = (type, value) => {
    setUpdatePosts((prev) => ({ ...prev, [type]: value }));
  };

  const onclickUpdate = () => {
    const err = {
      title: "",
      content: "",
      isError: false,
    };

    if (updatePosts.title.length === 0) {
      err.title = "please fill the title";
      err.isError = true;
    } else if (!nameRegex.test(updatePosts.title)) {
      err.title = "Valid Title";
      err.isError = true;
    } else if (nameRegex.test(updatePosts.title)) {
      err.title = "";
    }

    if (updatePosts.content.length === 0) {
      err.content = "please fill content";
      err.isError = true;
    } else if (!nameRegex.test(updatePosts.content)) {
      err.content = "Enter Valid Content";
      err.isError = true;
    } else if (nameRegex.test(updatePosts.content)) {
      err.content = "";
    }

    if (err.isError) {
      setInputError(err);
    } else {
      //   updatePosts(updatePosts).then((result) => {
      //     console.log(result);
      //     navigate("/homepage");
      //   });
    }
  };

  return (
    <>
      <Navigation />
      <div className="container">
        <div className="card">
          <div className="mb-3">
            <h5 className="card-title">Title</h5>
            <input
              className="form-control form-control-lg"
              type="text"
              value={updatePosts.title}
              placeholder="Enter Title"
              aria-label=".form-control-lg example"
              onChange={(e) => changeInput("title", e.target.value.trim())}
            />
            <p id="span" style={{ color: "red" }}>
              {inputError.title}
            </p>
          </div>
          <div className="mb-3">
            <h5 className="card-title">Content</h5>
            <input
              className="form-control form-control-lg"
              type="text"
              value={updatePosts.content}
              placeholder="Enter Content"
              aria-label=".form-control-lg example"
              onChange={(e) => changeInput("content", e.target.value.trim())}
            />
            <p id="span" style={{ color: "red" }}>
              {inputError.content}
            </p>
          </div>
        </div>
        <Button variant="outline-primary" onClick={onclickUpdate}>
          Update
        </Button>
        <Button
          variant="secondary"
          onClick={() => {
            navigate("/homepage");
          }}
        >
          Back
        </Button>
      </div>
    </>
  );
};
export default UpdatePosts;
