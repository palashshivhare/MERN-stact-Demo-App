import React, { useState } from "react";
import { useNavigate ,NavLink} from "react-router-dom";
import { emailRegex } from "../../utils/regex";

const ForgotPassword = () => {
  const navigate = useNavigate();
  const [loginDetails, setLoginDetails] = useState({ email: "" });
  const [error, setError] = useState("");

  const onClickSubmit = () => {
    if (loginDetails.email.length === 0) {
      setError({ isError: true, msg: "Please fill all the fields" });
    }
    if (!emailRegex.test(loginDetails.email)) {
      setError({ isError: true, msg: "Invaild Email" });
    }
    //    else {
    //     forgotPassword(loginDetails.email)
    //       .then((result) => {
    //         console.log(result);
    //         // navigate("/")
    //       })
    //       .catch((error) => {
    //         console.log(error);
    //         setError("Invalid Email");
    //       });
    //     // navigate('/')
    //   }
  };
  return (
    <>
      <nav className="navbar navbar-expand-lg bg-light">
        <div className="container-fluid">
          <a className="navbar-brand" href="#">
            DotSquares
          </a>
        </div>
        <button
          type="button"
          class="btn btn-secondary"
          onClick={() => {
            navigate("/login");
          }}
        >
          back
        </button>
      </nav>
      <div className="container">
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">
            Please Enter Email address
          </label>
          <input
            type="email"
            class="form-control"
            id="exampleFormControlInput1"
            placeholder="name@example.com"
          />
          <p>
            {error.isError && (
              <label
                htmlFor=""
                className="form-label"
                id="span"
                style={{ color: "red" }}
              >
                {error.msg}
              </label>
            )}
          </p>
          <button onClick={onClickSubmit}>Submit</button>
        </div>
      </div>
    </>
  );
};
export default ForgotPassword;
