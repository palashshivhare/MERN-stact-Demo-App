import "../signUp/appR.css";
import React, { useState, useEffect } from "react";
import FormInput from "../signUp/FormInput";
import { useNavigate, NavLink, Navigate } from "react-router-dom";

import { loginUser } from "../../api/Api";

const LoginUser = (props) => {
  const [isLoggedIn, setLoggedIn] = useState(false);
  const [loginDetails, setLoginDetails] = useState({ email: "", password: "" });
  const [formerror, setFormError] = useState({
    isError: false,
    email: "",
    password: "",
  });

  useEffect(() => {
    let userdata = JSON.parse(localStorage.getItem("user"));
    // console.log("vvvvvvvvvvvvvvvvvvvvv",userdata)
    if (userdata && userdata?._id) {
      console.log("iffffffffffffffffffffffffff", userdata?._id);
      navigate('./homepage')
    } else {
      console.log("elseeeeeeeeeeeeeeeeeeeeee", userdata?._id);
      // navigate("/login");
    }
  }, []);

  // const referer = props.location.state ? props.location.state.referer : '/homepage';

  const navigate = useNavigate();

  const onChangeInput = (type, value) => {
    setLoginDetails({ ...loginDetails, [type]: value });
  };

  const inputs = [
    {
      id: 1,
      name: "email",
      type: "email",
      placeholder: "Email",
      errorMessage: "It should be a valid email address!",
      label: "Email",
      pattern: `/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/`,
      required: true,
    },
    {
      id: 2,
      name: "password",
      type: "password",
      placeholder: "Password",
      errorMessage:
        "Password should be 8-20 characters and include at least 1 letter, 1 number and 1 special character!",
      label: "Password",
      pattern: `^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$`,
      required: true,
    },
  ];
  // const storedUser = (data) => {
  //   localStorage.setItem("loginuser", JSON.stringify(data));
  // };

  const handleSubmit = (e) => {
    e.preventDefault();
    loginUser({
      email: loginDetails.email,
      password: loginDetails.password,
    })
      .then((response) => {
        console.log("responseeee", response.data.data);
        setLoginDetails(response.data);
        // storedUser(response.data.data);
        navigate("/homepage");
        setLoggedIn(true);
      })
      .catch(() => {
        console.log("errorrrrrrrrrrrrr");
        setFormError({ isError: true, msg: "Invalid Email or Password" });
      });
  };
  // console.log("fffffffffffflogin", loginDetails);

  if (isLoggedIn) {
    return <Navigate to={"/homepage"} />;
  }

  const onChange = (e) => {
    setLoginDetails({
      ...loginDetails,
      [e.target.name]: e.target.value.trim(),
    });
  };

  return (
    <>
      <nav className="navbar navbar-expand-lg bg-light">
        <div className="container-fluid">
          <a className="navbar-brand" href="#">
            DotSquares
          </a>
        </div>
      </nav>
      <div className="app">
        <form onSubmit={handleSubmit}>
          <h1>Login User</h1>
          {inputs.map((input) => (
            <FormInput
              key={input.id}
              {...input}
              value={loginDetails[input.name]}
              onChange={onChange}
            />
          ))}
          {formerror.isError && (
            <label
              htmlFor=""
              className="form-label"
              id="span"
              style={{ color: "red" }}
            >
              {formerror.msg}
            </label>
          )}
          <br />
          <div className="form-check">
            <input
              type="checkbox"
              className="form-check-input"
              id="exampleCheck1"
            />
            <p
              className="form-check-label"
              htmlFor="exampleCheck1"
              style={{ padding: "10px" }}
            >
              Remember Me
            </p>
          </div>
          <button>Sign In</button>
          <div className="text-center pt-3 fsreg">
            <NavLink to="/forgotPassword">Forgot Password</NavLink>
          </div>
          <div className="text-center pt-3 fsreg">
            Don’t have an account? <NavLink to="/signUp">Sign up</NavLink>
          </div>
        </form>
      </div>
    </>
  );
};

export default LoginUser;
