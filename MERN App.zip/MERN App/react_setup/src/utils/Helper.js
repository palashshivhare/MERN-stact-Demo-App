
export const setuserDetail = (data) => {
   localStorage.setItem("user", JSON.stringify(data));
}
export const getuserDetail = () => {
  return JSON.parse(localStorage.getItem("user"));
};

export const setToken = (token) => {
  localStorage.setItem("api_token", token);
};

export const getToken = () => {
  return localStorage.getItem("api_token");
};
