import { fileOpen } from "browser-fs-access";

export async function csvInputFilePicker() {
  const blob = await fileOpen({
    description: "Csv file",
    mimeTypes: ["text/csv", "application/csv"],
    extensions: [".csv"],
  });

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(blob);

    reader.onload = () => {
      resolve(reader.result.split(",")[1]);
    };

    reader.onerror = () => {
      reject();
    };
  });
}

export async function imgsInputFilePicker() {
  const blobs = await fileOpen({
    multiple: true,
    description: "Image files",
    mimeTypes: ["image/jpg", "image/png"],
    extensions: [".jpg", ".jpeg", ".png"],
  });

  const promises = blobs.map((blob) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      const img = document.createElement("img");

      reader.readAsDataURL(blob);

      reader.onload = () => {
        img.src = reader.result;
      };

      img.onload = () => {
        resolve({ photo: reader.result.split(",")[1], photoName: blob.name });
      };

      img.onerror = () => {
        reject();
      };
    });
  });

  const results = await Promise.allSettled(promises);

  return results.reduce((newResult, result) => {
    if (result.status === "fulfilled") {
      return [...newResult, result.value];
    } else {
      return newResult;
    }
  }, []);
}

export async function imgInputFilePicker() {
  const blob = await fileOpen({
    description: "Image files",
    mimeTypes: ["image/jpg", "image/png"],
    extensions: [".jpg", ".jpeg", ".png"],
  });

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    const img = document.createElement("img");

    reader.readAsDataURL(blob);

    reader.onload = () => {
      img.src = reader.result;
    };

    img.onload = () => {
      resolve({ base64: reader.result.split(",")[1], name: blob.name });
    };

    img.onerror = () => {
      reject();
    };
  });

  // const input = document.createElement("input");
  // const img = document.createElement("img");

  // input.type = "file";
  // input.setAttribute("accept", ".jpg, .jpeg, .png");
  // const reader = new FileReader();
  // let filename = "";

  // input.onchange = (e) => {
  //     filename = e.target.files[0].name;
  //     reader.readAsDataURL(e.target.files[0]);
  // };

  // reader.onload = () => {
  //     img.src = `data:image/jpeg;base64,${reader.result.split(",")[1]}`
  //     // setFormData({ ...formData, photo: reader.result.split(",")[1], photoName: filename });
  // };

  // img.onload = () => {
  //     setFormData({ ...formData, photo: reader.result.split(",")[1], photoName: filename });
  // }

  // img.onerror = () => {
  //     console.log("error")
  // }

  // input.click();
}

export async function certificateInputFilePicker() {
  const blob = await fileOpen({
    description: "Image and Pdf files",
    mimeTypes: ["image/jpg", "application/pdf"],
    extensions: [".jpg", ".jpeg", ".pdf"],
  });

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    // const img = document.createElement("img");

    reader.readAsDataURL(blob);

    reader.onload = () => {
      // img.src = reader.result;
      resolve({ base64: reader.result.split(",")[1], name: blob.name });
    };

    // img.onload = () => {
    //     resolve({ base64: reader.result.split(",")[1], name: blob.name });
    // };

    // img.onerror = () => {
    //     reject();
    // };
  });
}

export function covertBase64ToDataUrl(base64) {
  return `data:image/jpeg;base64,${base64}`;
}
