export const nameRegex = /^[a-z A-Z]{1,50}$/;
export const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/;
export const phoneRegex = /^(\+\d{1,3}[- ]?)?\d{10}$/;
export const emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
export const numericRegex = /^-?\d+$/;
export const positiveNumericRegex = /^\d+$/;

export const regex = new RegExp(/^[a-zA-Z]{1,50}$/);
export const pattern = new RegExp(/^[0-9\b]+$/);
