import { configureStore } from "@reduxjs/toolkit"
import updateReducer from './UpdateSlice'

const store= configureStore({
    reducer:{
        update: updateReducer,
    }
})

export default store;