import { createSlice } from "@reduxjs/toolkit";

const UpdateSlice = createSlice({
  name: "update",
  initialState: [],
  reducers: {
    edit(state, action) {
      state.push(action.payload);
    },
  },
});

export const { edit } = UpdateSlice.actions;
export default UpdateSlice.reducer;
