module.exports = mongoose => {
    const createmanypost = mongoose.model(
        "createmanypost",
        mongoose.Schema(
            {
                userId: String,
                title: String,
                content: String,
            },
            { timestamps: true }
        )
    );
    return createmanypost;
};