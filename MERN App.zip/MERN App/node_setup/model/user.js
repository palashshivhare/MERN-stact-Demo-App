module.exports = mongoose => {
    const test2 = mongoose.model(
        "prac12",
        mongoose.Schema(
            {
                name: String,
                emailId: String,
                mobile: String,
                age: String,
            },
            { timestamps: true }
        )
    );
    return test2;
};