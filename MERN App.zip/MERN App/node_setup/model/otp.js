module.exports = mongoose => {
    const otp2 = mongoose.model(
        "forgotpassword",
        mongoose.Schema(
            {
                email: String,
                code: String,
                expiresIn: Number
            },
            { timestamps: true }
        )
    );
    return otp2;
};