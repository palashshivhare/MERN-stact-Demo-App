module.exports = mongoose => {
    const test2 = mongoose.model(
        "prac2",
        mongoose.Schema(
            {
                userId: String,
                name: String,
                email: String,
                DOB: Date,
                mobile: String,
                city: String,
                password: String,
            },
            { timestamps: true }
        )
    );
    return test2;
};