const express = require("express");
const app = express();
const port = 5001;
const test = require("./controller/test");
const bodyparser = require("body-parser");
var cors = require("cors");

// const nodemailer = require("nodemailer")
// const randomstring = require("randomstring")


const createToken = async() =>{
  const token = await jwt.sign({}, "")
};

app.use(bodyparser());
// app.use('/', (req, res)=>{
//     console.log("route api work");
//     res.send({message:"success"})
// })

app.use(cors());

app.use("/api", require("./routes/index"));
// app.use('/api', require('./routes'))

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});

