const db = require("../db");
const user = db.user;


exports.insertAll = (req, res) => {
    console.log("user insert api work");
    user
      .find()
      .then((data) => {
        res.send({ message: "sucess", data });
      })
      .catch((err) => {
        res.send({ message: "failed" });
      });
  };