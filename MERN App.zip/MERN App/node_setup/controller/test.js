const db = require("../db");
const test = db.test;
const createpost = db.createpost;

const { sign } = require("jsonwebtoken");

// const nodemailer = require("nodemailer");

// function fn(){
//   let mailTransporter = nodemailer.createTransport({
//     service: 'gmail',
//     host: "smtp.ethereal.email",
//     port: 587,
//     secure: false,
//     auth: {
//         user: 'palash.s01it@gmail.com',
//         pass: 'Oneplus@7697'
//     }
// });

// let mailDetails = {
//     from: 'palash.s01it@gmail.com', //-------- sender email
//     to: 'itguypalash@gmail.com', //-------- receiver email
//     subject: 'Test mail', //-------- subject do you want
//     text: 'Node.js testing mail for SIT', //-------- message
//     html: "<b>Hello world?</b> <i>Tanuj Sahu Here<i>", // html body
// };

// mailTransporter.sendMail(mailDetails, function (err, data) {
//     if (err) {
//         console.log('Error Occurs');
//     } else {
//         console.log('Email sent successfully');
//     }
// });
// }

exports.create = (req, res) => {
  console.log("test create api work", req.body);
  let obj = test(req.body);
  obj
    .save(req.body)
    .then((data) => {
      console.log('dataaaaaaaa', data)
      res.send({ message: "sucess contoller", data: data });
    })
    .catch((error) => {
      res.status(400).send({ message: "create error", error: error });

    });
};

exports.createpost = (req, res) => {
  console.log("test create Post api work", req.body);
  let obj = createpost(req.body);
  obj
    .save(req.body)
    .then((data) => {
      res.send({ message: "sucess contoller", data: data });
    })
    .catch((error) => {
      res.send({ message: "create error", error: error });
    });
};

exports.getAllposts = (req, res) => {
  // fn()
  console.log("test getAll post api work");
  createpost
    .find({ userId: req.body.userId })
    .then((data) => {
      res.send({ message: "sucess", data });
    })
    .catch((err) => {
      res.send({ message: "failed" });
    });
};

exports.updatepost = (req, res) => {
  console.log("test update post api workhhhhhhhhhhh", req.params);
  createpost
    .findByIdAndUpdate({ _id: req.params.userId }, req.body)
    .then((data) => {
      res.send({ message: "updated Post sucessfully", data });
    })
    .catch((err) => {
      res.send({ message: "update post failed" });
    });
};

exports.deletepost = (req, res) => {
  console.log("test delete post api work", req.params);
  createpost
    .deleteOne({ _id: req.params.userId })
    .then((data) => {
      res.send({ message: "deleted Post sucessfully", data });
    })
    .catch((err) => {
      res.send({ message: "delete post failed" });
    });
};

exports.login = (req, res) => {
  console.log("test Login api workdfvfv", req.body);
  test
    .findOne({
      $and: [{ email: req.body.email }, { password: req.body.password }],
    })
    .then((data) => {
      console.log(data,"dataaaaa")
      if (data) {
        const jsontoken = sign({ result: data[0] }, "Palash#123?", {
          expiresIn: "1h",
        });
        console.log("JSON TOKEN__________", jsontoken);

        console.log("sucesss", data);
        res.send({
          message: "sucess loginn",
          data: data,
          jsontoken: jsontoken,
        });
      } else {
        console.log("failed");
        res.status(500).send({ message: "loginn failed" });
      }
    })
    .catch((error) => {
      res.send({ message: "error", error: error });
    });
};

exports.forgotpassword = (req, res) => {
  console.log("test forgotPass api work", req.body);
  test
    .findOne({
      $and: [{ email: req.body.email }],
    })
    .then((data) => {
      if (data) {
        console.log("sucesss", data, data.length);
        res.send({ message: "sucess forgot", data: data });
      } else {
        console.log("failed");
        res.status(500).send({ message: "forgot failed" });
      }
    })
    .catch((error) => {
      res.send({ message: "error", error: error });
    });
};

exports.getAll = (req, res) => {
  console.log("test create api work");
  test
    .find()
    .then((data) => {
      res.send({ message: "sucess", data });
    })
    .catch((err) => {
      res.send({ message: "failed" });
    });
};

exports.delete = (req, res) => {
  console.log("test delete api work", req.params);
  test
    .deleteOne({ name: req.params._id })
    .then((data) => {
      res.send({ message: "deleted sucessfully", data });
    })
    .catch((err) => {
      res.send({ message: "delete failed" });
    });
};

exports.update = (req, res) => {
  console.log("test uodate api work", req.body);
  test
    .findByIdAndUpdate({ _id: req.body._id }, req.body)
    .then((data) => {
      res.send({ message: "sucess contoller", data: data });
    })
    .catch((error) => {
      res.send({ message: "update error", error: error });
    });
};
