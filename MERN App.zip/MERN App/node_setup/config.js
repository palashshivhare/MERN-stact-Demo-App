module.exports = {
  host: "0.0.0.0",
  serverPort: 3009,
  fileMaxSize: 5 * 1024 * 1024,
  mongoUrl: "mongodb://localhost:27017/nodeprac2",
  lang: "en",
  fileMaxSize: 52428800,
};
