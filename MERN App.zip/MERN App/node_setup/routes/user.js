const router = require('express').Router();
const user = require("../controller/user");


router.post("/insert", user.insertAll);

module.exports = router;