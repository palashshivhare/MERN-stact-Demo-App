// const express = require('express')
// const router = express.Router(); 

// router.use('test',require('./test'))

// exports.router

const express = require('express');
var router=express.Router();

router.use('/test', require('./test'))
router.use('/user', require('./user'))


module.exports = router;
// export const router = router