const router = require("express").Router();
const test = require("../controller/test");
const { validateToken } = require("../auth/jwtAuthentication");

router.post("/create", test.create);
router.post("/createpost", validateToken, test.createpost);
router.post("/getallpost", validateToken, test.getAllposts);
router.delete("/deletepost/:userId", validateToken, test.deletepost);
router.post("/forgotpassword", test.forgotpassword);
router.post("/updatepost/:userId", validateToken, test.updatepost);

router.post("/login", test.login);
router.get("/userlist", test.getAll);
router.delete("/delete/:_id", test.delete);
router.post("/update", test.update);

// router.get("/", test.create);

module.exports = router;
