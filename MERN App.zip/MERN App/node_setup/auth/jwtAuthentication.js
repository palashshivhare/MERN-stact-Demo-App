const {verify} = require('jsonwebtoken')

exports.validateToken = (req,res,next)=>{
    let token = req.headers['authorization'];
    console.log("This is the token from auth",token);
    if(token){
        // token = token.split(' ')
        // token = token.slice(7);
        verify(token,'Palash#123?',(err,data)=>{
            if(err){
                console.log('err', err)
                res.status(400).json({
                    success:0,
                    message:"Invalid token"
                })
            }else{
                // req.body.id = data.result._id;
                // console.log("this is userid",data.result.id);
                next();
            }
        });
    }else{
        res.status(400).json({
            success:0,
            message:"Access denied! unauthorized user"
        })
    }
}